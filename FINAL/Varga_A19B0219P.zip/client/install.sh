#!/bin/bash
sudo apt install python3
sudo apt install python3-tk
sudo apt install pip
pip install -r ./requirements.txt --user
